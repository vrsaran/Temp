package com.reference.commitment.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
@EnableConfigurationProperties
public class MyYamlConfig {

	private String name;
    private String environment;
    private List<String> servers = new ArrayList<>();

    private String driver;
	  
	  private String password;
	  
	  private String url;
	  
	  private String username;

	  private String hibernate_dialect;
	  
	  private String hibernate_show_sql;
	  
	  private String hibernate_ddl_auto;

	
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getHibernate_dialect() {
		return hibernate_dialect;
	}
	public void setHibernate_dialect(String hibernate_dialect) {
		this.hibernate_dialect = hibernate_dialect;
	}
	public String getHibernate_show_sql() {
		return hibernate_show_sql;
	}
	public void setHibernate_show_sql(String hibernate_show_sql) {
		this.hibernate_show_sql = hibernate_show_sql;
	}
	public String getHibernate_ddl_auto() {
		return hibernate_ddl_auto;
	}
	public void setHibernate_ddl_auto(String hibernate_ddl_auto) {
		this.hibernate_ddl_auto = hibernate_ddl_auto;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public List<String> getServers() {
		return servers;
	}
	public void setServers(List<String> servers) {
		this.servers = servers;
	}
    
}

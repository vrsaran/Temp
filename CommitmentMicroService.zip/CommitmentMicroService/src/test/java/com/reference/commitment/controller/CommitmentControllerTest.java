package com.reference.commitment.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.reference.commitment.controller.repository.CommitmentRepository;
import com.reference.commitment.entity.CommitmentEntity;

@RunWith(MockitoJUnitRunner.class)
public class CommitmentControllerTest {/*

	@InjectMocks
	CommitmentsControllerr orderControllerMock;

	@Mock
	CommitmentRepository orderRepositoryMock;

	@Test
	public void testAddOrder() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		CommitmentEntity locObj = new CommitmentEntity();
		locObj = orderEntity;

		when(orderRepositoryMock.save(orderEntity)).thenReturn(locObj);
		orderControllerMock.addOrder(orderEntity);

		assertEquals("Add Order Result: ", orderEntity.getOrderId(), locObj.getOrderId());
	}
	
	@Test
	public void testAddOrderFail() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		CommitmentEntity locObj = new CommitmentEntity();

//		when(orderRepositoryMock.save(orderEntity)).thenReturn(locObj);
		orderControllerMock.addOrder(locObj);

		assertNotEquals("Add Order Fail Result: ", orderEntity.getOrderId(), locObj.getOrderId());
	}

	@Test
	public void testGetOrder() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		Optional<CommitmentEntity> locObj = Optional.of(orderEntity);

		when(orderRepositoryMock.findById(orderEntity.getOrderId())).thenReturn(locObj);
		orderControllerMock.getOrder(orderEntity.getOrderId());

		assertEquals("Get Order Result: ", orderEntity.getOrderId(), locObj.get().getOrderId());
	}

	@Test
	public void testGetOrderFail() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		Optional<CommitmentEntity> locObj = Optional.of(orderEntity);
		locObj.get().setOrderId(654321);
		
		when(orderRepositoryMock.findById(orderEntity.getOrderId())).thenReturn(locObj);
		orderControllerMock.getOrder(orderEntity.getOrderId());

		assertEquals("Get Order Fail Result: ", orderEntity.getOrderId(), locObj.get().getOrderId());
		assertNotEquals(orderEntity, locObj);
	}
	
	@Test
	public void testUpdateOrder() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		CommitmentEntity locObj = new CommitmentEntity();
		locObj = orderEntity;
		locObj.setOrderId(654321);
		locObj.setBusinessUnit("Banking");

		when(orderRepositoryMock.save(orderEntity)).thenReturn(locObj);
		orderControllerMock.updateOrder(locObj);

		assertEquals("Update Order Result: ", "654321", locObj.getOrderId().toString());
	}
	
	@Test
	public void testUpdateOrderFail() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		CommitmentEntity locObj = new CommitmentEntity();
		locObj = orderEntity;
		locObj.setOrderId(654321);

		CommitmentEntity locObj2 = new CommitmentEntity();
//		when(orderRepositoryMock.save(orderEntity)).thenReturn(locObj);
		orderControllerMock.updateOrder(locObj2);

		//assertNotEquals("Update Order Fail Result: ", "654321", locObj.getOrderId().toString());
		assertNotEquals(locObj2, orderEntity);
	}

	@Test
	public void testDeleteOrder() throws Exception {

		CommitmentEntity orderEntity = new CommitmentEntity();
		orderEntity.setOrderId(123456);
		orderEntity.setBusinessUnit("Credit");
		orderEntity.setCorporateAccountId(1234567890);
		orderEntity.setDestinationArea("USA");
		orderEntity.setLineOfBusinessId(123456789);
		orderEntity.setOriginArea("INDIA");
		orderEntity.setServiceOffering("TRADING");

		CommitmentEntity locObj = new CommitmentEntity();
		locObj = orderEntity;

		orderRepositoryMock.deleteById(orderEntity.getOrderId());
		orderControllerMock.deleteOrder(locObj.getOrderId());

		assertEquals("Delete Order Result: ", orderEntity.getOrderId(), locObj.getOrderId());
	}

*/}

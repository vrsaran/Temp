package com.reference.commitment.controller.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reference.commitment.entity.CommitmentEntity;

public interface CommitmentRepository extends JpaRepository<CommitmentEntity, Integer> {

}

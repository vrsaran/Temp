package com.reference.commitment.dal;

import java.util.List;

import com.reference.commitment.entity.CommitmentEntity;

public class CommitmentServiceImpl implements CommitmentService {

	@Override
	public List<CommitmentEntity> getAllEntity() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CommitmentEntity getEntityByCommitmentId(Integer commitmentId) {
		// TODO Auto-generated method stub
		return null;
	}

}

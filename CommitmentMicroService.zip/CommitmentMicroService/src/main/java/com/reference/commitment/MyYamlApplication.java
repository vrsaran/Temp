package com.reference.commitment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.reference.commitment.config.MyYamlConfig;

@SpringBootApplication
public class MyYamlApplication implements CommandLineRunner {

	@Autowired
	private MyYamlConfig myConfig;

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(MyYamlApplication.class);
		app.run();
	}

	public void run(String... args) throws Exception {
		System.out.println("using environment: " + myConfig.getEnvironment());
		System.out.println("name: " + myConfig.getName());
		System.out.println("servers: " + myConfig.getServers());
	}
}
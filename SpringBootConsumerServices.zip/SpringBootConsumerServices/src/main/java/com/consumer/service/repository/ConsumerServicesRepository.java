package com.consumer.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.consumer.service.model.ConsumerServices;

public interface ConsumerServicesRepository extends JpaRepository<ConsumerServices, Long> {

}

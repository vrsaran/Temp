package com.consumer.service.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.consumer.service.model.ConsumerServices;
import com.consumer.service.repository.ConsumerServicesRepository;


@Controller
public class ConsumerServicesController {

	@Autowired
	private ConsumerServicesRepository consRepo;

	@RequestMapping(value = "/addNewConsumerServices.html", method = RequestMethod.POST)
	public String newConsumerServices(ConsumerServices conObj) {

		consRepo.save(conObj);
		return ("redirect:/listConsumers.html");

	}
	

	@RequestMapping(value = "/addNewConsumerServices.html", method = RequestMethod.GET)
	public ModelAndView addNewConsumerServices() {

		ConsumerServices emp = new ConsumerServices();
		return new ModelAndView("newConsumerServices", "form", emp);

	}

	@RequestMapping(value = "/listConsumers.html", method = RequestMethod.GET)
	public ModelAndView employees() {
		
		List<ConsumerServices> allConsumess = consRepo.findAll();
		return new ModelAndView("allConsumerServices", "consumers", allConsumess);

	}
	
	/*@RequestMapping(value = "/allConsumerServices.jsp", method = RequestMethod.GET)
	public ModelAndView consumers() {
		List<ConsumerServices> allConsumess = consRepo.findAll();
		return new ModelAndView("allConsumerServices", "consumers", allConsumess);

	}*/
	
}

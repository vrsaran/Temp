package com.consumer.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableAutoConfiguration
@SpringBootApplication
public class SpringBootConsumerServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootConsumerServicesApplication.class, args);
	}
}

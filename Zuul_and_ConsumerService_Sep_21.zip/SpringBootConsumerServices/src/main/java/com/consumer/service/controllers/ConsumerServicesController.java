package com.consumer.service.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.consumer.service.model.ConsumerServices;
import com.consumer.service.repository.ConsumerServicesRepository;


@Controller
public class ConsumerServicesController {

	@Autowired
	private ConsumerServicesRepository consRepo;

	@RequestMapping(value = "/addNewConsumerServices.html", method = RequestMethod.POST)
	public String newConsumerServices(ConsumerServices conObj) {

		System.out.println("Service Name:: " +conObj.toString());
//		consRepo.save(conObj);
//		return ("redirect:/listConsumers.html");
		System.out.println("Service Name:: " +conObj.getName());
		return ("redirect:/serviceResult.html");

	}
	

	@RequestMapping(value = "/addNewConsumerServices.html", method = RequestMethod.GET)
	public ModelAndView addNewConsumerServices() {

		ConsumerServices emp = new ConsumerServices();
		System.out.println("Sservice namee:: " +emp.getName());
		return new ModelAndView("newConsumerServices", "form", emp);

	}

	@RequestMapping(value = "/listConsumers.html", method = RequestMethod.GET)
	public ModelAndView employees() {
//		http://localhost:8086/CommitmentMicroService/commitment/getCommitment/all
		List<ConsumerServices> allConsumess = consRepo.findAll();
		
		/*
		String greeting = this.restTemplate.getForObject("http://localhost:8086/CommitmentMicroService/commitment/getCommitment/all", String.class);
        System.out.println("OUT:: " +greeting);*/
        
		return new ModelAndView("allConsumerServices", "consumers", allConsumess);

	}
	
	@RequestMapping(value = "/serviceResult.html", method = RequestMethod.GET)
	public ModelAndView servicesResult(@RequestParam(value = "response", defaultValue = "Service Result empty") String response) {
		if(response.equalsIgnoreCase("Service Result empty")) {
			response = this.restTemplate.getForObject("http://localhost:8086/commitment/getCommitment/all", String.class);
		}else {
			response = "Service Result empty Service";
		}
		
        System.out.println("OUT:: " +response);
        
		return new ModelAndView("allServicesResult", "results", response);

	}
	
	@RequestMapping(value = "/serviceResult.html", method = RequestMethod.POST)
	public ModelAndView logout() {

		ConsumerServices emp = new ConsumerServices();
		System.out.println("Re-login:: " +emp.getName());
		return new ModelAndView("login", "form", emp);
		
		//return ("redirect:/login.jsp");

	}
	
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }
    @Autowired
    RestTemplate restTemplate;
	
}
